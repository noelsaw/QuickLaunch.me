<?php
/**
 * QuickLaunch Theme
 * Functions File
 *
 * @package QuickLaunch
 * @version 1.1
 * @since 1.0
 * @author brux <brux.romuar@gmail.com>
 */

require_once TEMPLATEPATH . '/includes/QL_JSONResponse.php';
require_once TEMPLATEPATH . '/includes/QL_Email.php';
require_once TEMPLATEPATH . '/includes/admin.php';
require_once TEMPLATEPATH . '/includes/personalization.php';
require_once TEMPLATEPATH . '/includes/campaign.php';

// Setup the database
$db_setup = <<<DB_SETUP
CREATE TABLE IF NOT EXISTS {$wpdb->prefix}quicklaunch_emails (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  email varchar(255) CHARACTER SET utf8 NOT NULL,
  ip varchar(15) CHARACTER SET utf8 NOT NULL,
  registered_on datetime NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;
DB_SETUP;
$wpdb->query($db_setup);

// Default page content
$default_page_content = <<<DEF_PAGE_CONTENT
	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>
DEF_PAGE_CONTENT;
add_option('ql-page-content', $default_page_content);

add_option('ql-content-padding', '20');
add_option('ql-btn-color', 'gray');

// Register our nav menus
//register_nav_menu('bottom', 'Bottom Menu');

/**
 * Prepares the environment for QuickLaunch.
 *
 * @return void
 * @since 1.0
 */
function ql_init()
{

	// If we are Personalizing the theme, set a flag.
	if ( isset($_GET['personalize']) && current_user_can('edit_theme_options') )
	{
		define('QL_PERSONALIZING', true);
	}

}
add_action('init', 'ql_init');

/**
 * Registers and enqueues the Javascript and CSS files needed by the theme.
 *
 * @return void
 * @since 1.0
 */
function ql_add_scripts()
{

	$template_url = get_bloginfo('template_url');
	
	wp_register_style('eye-colorpicker', $template_url .'/js/colorpicker/colorpicker.css');
	wp_register_style('jq-ui', $template_url .'/css/jquery/jquery.ui.css');

	wp_register_script('eye-colorpicker', $template_url .'/js/colorpicker/jquery.colorpicker.js', array('jquery'));
	wp_register_script('nouislider', $template_url .'/js/jquery.nouislider.js', array('jquery'));
	
	wp_register_script('ql-scripts', $template_url . '/js/scripts.js', array('jquery'));
	wp_register_script('ql-admin', $template_url . '/js/admin.js', array('jquery', 'eye-colorpicker', 'plupload-html5', 'plupload-flash', 'nouislider'));
	
	if ( ql_is_personalizing() )
	{
	
		wp_enqueue_style('eye-colorpicker');
		wp_enqueue_style('jq-ui');
	
		$vars = array(
			'ajaxurl' => admin_url('admin-ajax.php'),
			'siteurl' => get_bloginfo('url'),
			'upload_nonce' => wp_create_nonce('quicklaunch-upload-file'),
			'save_nonce' => wp_create_nonce('quicklaunch-save-personalization')
		);
		wp_localize_script('ql-admin', 'QLAdmin', $vars);
		wp_enqueue_script('ql-admin');
		wp_enqueue_script('jquery-ui-dialog');
		
	}
	else
	{
		
		$vars = array(
			'ajaxurl' => admin_url('admin-ajax.php'),
			'reg_email_nonce' => wp_create_nonce('quicklaunch-register-email')
		);
		wp_localize_script('ql-scripts', 'QL', $vars);
		wp_enqueue_script('ql-scripts');
		
	}
	
	if ( is_admin() && basename($_SERVER['PHP_SELF']) == 'admin.php' && $_GET['page'] == 'ql-email-list' )
	{
		wp_enqueue_script('common');
	}

}
add_action('wp_head', 'ql_add_scripts');
add_action('admin_head', 'ql_add_scripts');

/**
 * Fallback function for the bottom menu. Prints an empty Nav container.
 *
 * @return void
 * @since 1.0
 */
function ql_bottom_nav()
{
?>
	<nav id="footer-nav"></nav>
<?php
}

/**
 * Adds the "personalize" button on the admin bar.
 *
 * @return void
 * @since 1.1
 */
function ql_admin_bar()
{

	if ( current_user_can('edit_theme_options') && ! ql_is_personalizing() )
	{
		
		global $wp_admin_bar;
		
		if ( ! is_super_admin() || ! is_admin_bar_showing() )
				return;
		
		$wp_admin_bar->add_menu(array(
			'id' => 'ql-personalize',
			'title' => 'Edit site',
			'href' => get_bloginfo('url') . '?personalize'
		));
		
	}

}
add_action('admin_bar_menu', 'ql_admin_bar', 75);

/**
 * Automatically adds links to valid URLs in our post content.
 *
 * @param string $content the post content
 * @return string
 * @since 1.1
 * @credit http://www.couchcode.com/php/auto-link-function/
 */
function ql_auto_link($content)
{
	if(!ql_is_personalizing()){
		$pattern = "/(((http[s]?:\/\/)|(www\.))(([a-z][-a-z0-9]+\.)?[a-z][-a-z0-9]+\.[a-z]+(\.[a-z]{2,2})?)\/?[a-z0-9._\/~#&=;%+?-]+[a-z0-9\/#=?]{1,1})/is";
		$content = preg_replace($pattern, " <a href='$1'>$1</a>", $content);
		$content = preg_replace("/href='www/", "href='http://www", $content);
		return $content;
	}else
		return $content;

}
add_filter('the_content', 'ql_auto_link');

/**
 * Sidebar widgets
 */
function ql_widgets_init(){
	register_sidebar( array(
		'name' => 'Top Sidebar',
		'id' => 'sidebar-top',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
}
add_action( 'widgets_init', 'ql_widgets_init' );

/**
 * Get Youtube video id from a youtube url
 * @param string Youtube video url
 * @return string video id
 */
function get_youtube_video_id($url){
	$params = parse_str(parse_url ($url, PHP_URL_QUERY));
	// get only v param
	return $v;
}

/**
 * Set Thank you message
 */
function ql_admin_footer(){
	if(!get_option('ql-active')){
		// add option
		add_option('ql-active', 'active');
		
		// set activation message
		echo '<div style="padding:15px;" class="updated">Thanks for installing Quicklaunch. Start <a href="'.get_bloginfo('url') . '?personalize'.'">Editing</a> your site.</div>';
	}
	
	wp_enqueue_script('jQuery');
	// add Edit site link
	echo '<script type="text/javascript">jQuery(document).ready(function(){ jQuery("#current-theme .theme-options a").each(function(){ if(jQuery(this).attr("href") == "nav-menus.php") jQuery(this).remove(); }); jQuery("#current-theme .theme-options").append(" <a href=\"'.get_bloginfo('url') . '?personalize'.'\">Edit site</a>"); });</script>';
	
}
add_action('admin_footer', 'ql_admin_footer');

?>
