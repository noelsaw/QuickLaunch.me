
	<?php if ( is_active_sidebar( 'sidebar-top' ) ) : ?>
		<section class="widget-area">
			<?php dynamic_sidebar( 'sidebar-top' ); ?>
		</section><!-- #second .widget-area -->
	<?php endif; ?>
