<!DOCTYPE html>
<html lang="<?php bloginfo('language') ?>">
<head>

	<meta charset="<?php bloginfo('charset') ?>">
	
	<title><?php bloginfo('title') ?></title>
	
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url') ?>">

	<!--[if lt IE 9]>
	<script src="<?php bloginfo('template_url') ?>/js/html5.js"></script>
	<![endif]-->

	<?php wp_head() ?>

</head>
<body style="color:<?php echo get_option('ql-text-color', '#000'); ?>">

	<!-- Page Wrapper -->
	<div id="wrap" class="pos-<?php echo get_option('ql-content-position', 'center'); ?> <?php echo (get_option('ql-rounded-box-background'))?'rounded-box-background': ''; ?>" style="background-color:rgba(255, 255, 255, <?php echo get_option('ql-box-opacity', 1); ?>)" >
		<div id="wrap-inner">
	
