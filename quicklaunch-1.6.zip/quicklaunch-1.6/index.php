<?php get_header() ?>
	
		<!-- Page Header -->
		<header>
			<?php if(get_option('ql-logo-image')): ?>
				<img src="<?php echo get_option('ql-logo-image'); ?>" style="max-width:100%;" />
			<?php else: ?>
				<h1 id="site-title" style="color:<?php echo get_option('ql-heading-color', '#000'); ?>" ><?php echo stripslashes(get_bloginfo('title')) ?></h1>
				<h2 id="site-desc"><?php echo stripslashes(get_bloginfo('description')) ?></h2>
			<?php endif; ?>
		</header>
		<!-- End Page Header -->
		<div id="widgets" class="<?php echo get_option('ql-widgets-active')?'':'hidden' ?>" >
			<?php get_sidebar('top'); ?>
		</div>
		<!-- Center Image -->
		<section id="center-image" class="<?php echo get_option('ql-center-image')?'':'hidden' ?>" >
<?php if ( get_option('ql-center-image') ): ?>
			<img src="<?php echo get_option('ql-center-image') ?>" width="<?php echo (500 - (get_option('ql-content-padding') * 2)) ?>">
<?php endif; ?>
		</section>
		<!-- End Center Image -->
		
		<!-- Video -->
		<section id="video" class="<?php echo get_option('ql-video')?'':'hidden' ?>" >
			<object width="<?php echo (500 - (get_option('ql-content-padding') * 2)) ?>" height="315">
			  <param name="movie"
					 value="http://www.youtube.com/v/<?php echo get_youtube_video_id(get_option('ql-video')); ?>&version=3&autohide=1&showinfo=0"></param>
			  <param name="allowScriptAccess" value="always"></param>
			  <embed src="http://www.youtube.com/v/<?php echo get_youtube_video_id(get_option('ql-video')); ?>&version=3&autohide=1&showinfo=0"
					 type="application/x-shockwave-flash"
					 allowscriptaccess="always"
					 width="<?php echo (500 - (get_option('ql-content-padding') * 2)) ?>" height="315"></embed>
			</object>
		</section>
		<!-- End Video -->
		
		<!-- Main Content -->
		<section id="content">
		
			<div id="page-content">
				<?php echo apply_filters('the_content', stripslashes(get_option('ql-page-content'))) ?>
			</div>
			
			<form action="" method="post" class="newsletter-form <?php echo (get_option('ql-show-email'))?'':'hidden' ?>">
				<p>
					<input type="text" name="email" value="" placeholder="Signup for email newsletters" size="50" class="email"> 
					<input type="submit" name="submit" value="Submit" id="newsletter-submit" class="btn <?php echo get_option('ql-btn-color') ?>">
				</p>
			</form>
		
		</section>
		<!-- End Main Content -->
		
		<!-- Footer -->
		<footer class="clearfix">
		
			<!-- Copyright -->
			<div id="copyright">
				<p>&copy; Copyright <?php echo date('Y') ?> <span id="company"><?php if(get_option('ql-company')) echo stripslashes(get_option('ql-company')); else stripcslashes(bloginfo('title')); ?></span></p>
			</div>
			<!-- End Copyright -->
			
			<!-- Footer Nav -->
			<!-- End Footer Nav -->
			
			<!-- Social Networks -->
			<nav id="social-networks">
				<ul>
<?php if ( get_option('ql-twitter-url') ): ?>
					<li><a href="<?php echo get_option('ql-twitter-url') ?>"><img src="<?php bloginfo('template_url') ?>/images/twitter.png" alt="Twitter"></a></li>
<?php endif; ?>
<?php if ( get_option('ql-facebook-url') ): ?>
					<li><a href="<?php echo get_option('ql-facebook-url') ?>"><img src="<?php bloginfo('template_url') ?>/images/facebook.png" alt="Facebook"></a></li>
<?php endif; ?>
<?php if ( get_option('ql-linkedin-url') ): ?>
					<li><a href="<?php echo get_option('ql-linkedin-url') ?>"><img src="<?php bloginfo('template_url') ?>/images/linkedin.png" alt="LinkedIn"></a></li>
<?php endif; ?>
<?php if ( get_option('ql-googleplus-url') ): ?>
					<li><a href="<?php echo get_option('ql-googleplus-url') ?>"><img src="<?php bloginfo('template_url') ?>/images/googleplus.png" alt="Google+"></a></li>
<?php endif; ?>
<?php if ( get_option('ql-youtube-url') ): ?>
					<li><a href="<?php echo get_option('ql-youtube-url') ?>"><img src="<?php bloginfo('template_url') ?>/images/youtube.png" alt="YouTube"></a></li>
<?php endif; ?>
				</ul>
			</nav>
			<!-- End Social Networks -->
			
		</footer>
		<!-- End Footer -->
		
<?php get_footer() ?>
