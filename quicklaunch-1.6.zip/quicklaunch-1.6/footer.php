		</div>
		<!-- End inner wrapper -->
	</div>
	<!-- End Page Wrapper -->

	<?php wp_footer() ?>
<?php if ( ql_is_personalizing() ): get_template_part('template-admin-palette'); endif; ?>
	<script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
	<script type="text/javascript">
			<?php if(get_option('ql-google-font')): ?>
			WebFont.load({
				google: {
					families: ['<?php echo get_option('ql-google-font'); ?>']
				},
				active:function(){
					var style = 'header h1{ font-family: "<?php echo get_option('ql-google-font'); ?>"; }';
					
					var sc=document.createElement('style')
					  sc.setAttribute("type","text/css");
					  sc.innerHTML= style;
					  document.getElementsByTagName("head")[0].appendChild(sc)
				}
			});
			<?php endif; ?>
	</script>
</body>
</html>
